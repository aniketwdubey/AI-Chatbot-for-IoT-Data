import json
import boto3
import csv
from io import StringIO

s3 = boto3.client('s3')


def fetch_data_from_s3():
    bucket_name = 'lex-chatbot-bucket-for-iot-data'
    object_key = 'Energy Consumption Data.csv'

    response = s3.get_object(Bucket=bucket_name, Key=object_key)
    content = response['Body'].read().decode('utf-8')

    data = list(csv.DictReader(StringIO(content)))

    return data


def get_current_energy(data):
    latest_entry = data[-1]
    current_energy = latest_entry['kwh']
    return current_energy


def get_average_energy(data):
    total_energy = 0.0
    count = 0

    for entry in data:
        energy = entry['kwh']
        try:
            energy_value = float(energy.split()[0])
            total_energy += energy_value
            count += 1
        except (ValueError, IndexError):
            continue

        if count > 0:
            average_energy = total_energy / count

    return average_energy


def lambda_handler(event, context):

    data = fetch_data_from_s3()

    intent_name = event['interpretations'][0]['intent']['name']
    response = "I'm sorry, I couldn't retrieve the information."

    if intent_name == 'GetCurrentUsageIntent':
        current_energy = get_current_energy(data)
        if current_energy:
            response = f"The current energy consumption is {current_energy}."
        else:
            response = "Data not available."

    if intent_name == 'GetAverageUsage':
        average_energy = get_average_energy(data)
        if average_energy:
            response = f"The average energy consumption of this month is {average_energy:.2f} Wh."
        else:
            response = "Data not available."

    intent = {
        "state": "Fulfilled",
        "name": intent_name,
    }

    return {"sessionState": {
        "activeContexts": [
            {
                "name": "string",
                "contextAttributes": {
                    "key": "value"
                },
                "timeToLive": {
                    "timeToLiveInSeconds": 10,
                    "turnsToLive": 10
                }
            }
        ],
        "sessionAttributes": {
            "string": "string"
        },
        "dialogAction": {
            "slotElicitationStyle": "Default",
            "slotToElicit": "string",
            "type": "ElicitIntent"
        },
        "intent": intent
    },
        "messages": [
        {
            "contentType": "CustomPayload",
            "content": response

        }
    ],
        "requestAttributes": {
        "string": "string"
    }
    }
